# Screenshots for Task04

Place your code snapshot and terminal execution output images here:
- `Task04_code_ss.png`
- `Task04_output_ss.png`
