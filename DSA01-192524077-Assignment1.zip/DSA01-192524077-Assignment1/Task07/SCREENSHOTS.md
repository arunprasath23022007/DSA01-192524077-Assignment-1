# Screenshots for Task07

Place your code snapshot and terminal execution output images here:
- `Task07_code_ss.png`
- `Task07_output_ss.png`
