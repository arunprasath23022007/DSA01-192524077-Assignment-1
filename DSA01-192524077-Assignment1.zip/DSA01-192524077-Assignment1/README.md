# Namma Metro Smart-Card Fare System (C++ OOP)
**Student Name:** Arunprasath R  
**Register Number:** 192524077  
**Course Code:** DSA01 - Assignment 1  
**Target Environment:** Linux / macOS / Windows (VS Code)  
**Compiler:** g++ (GCC) 13.x / C++17 Standard  

## Compilation & Execution
To compile and execute any task module:
```bash
# Example: Task 06
g++ -std=c++17 -Wall -Wextra -pedantic Task06/main.cpp -o Task06/run
./Task06/run

# Example: Task 09 Automated Test Suite
g++ -std=c++17 -Wall -Wextra -pedantic Task09/fare_system_test.cpp -o Task09/test_suite
./Task09/test_suite

# Example: Task 12 Design Challenge
g++ -std=c++17 -Wall -Wextra -pedantic Task12/metro_challenge_v2.cpp -o Task12/challenge
./Task12/challenge
```

## Directory Overview
- **Task 01:** Object-Oriented Problem Analysis & Domain Modeling.
- **Task 02:** Language Tokens, Scoped Enums (`enum class`), and `constexpr` tables.
- **Task 03:** Data Types, Precision Analysis, and Integer Paise Accounting.
- **Task 04:** Implicit Conversions, Integral Promotions, and Static Casts.
- **Task 05:** Operator Precedence, Associativity, and Peak-Hour Window Expressions.
- **Task 06:** Control Structures & Selection Logic for Fare Deduction.
- **Task 07:** Procedural vs. Object-Oriented Architecture & Invariant Protection.
- **Task 08:** Safe Stream I/O, Error Recovery, and Formatted Gate Pass Output.
- **Task 09:** Complete Fare Engine Implementation & Automated Assertion Suite.
- **Task 10:** 3,000,000 Journey Stress Testing & Type Overflow Demonstration.
- **Task 11:** Production Architecture Recommendations & System Defense.
- **Task 12:** Day-4 Design Challenge (Airport Zone, Weekend Rules, and Monthly Pass).
