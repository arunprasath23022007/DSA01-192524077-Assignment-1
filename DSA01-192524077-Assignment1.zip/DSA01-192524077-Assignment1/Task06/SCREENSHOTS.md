# Screenshots for Task06

Place your code snapshot and terminal execution output images here:
- `Task06_code_ss.png`
- `Task06_output_ss.png`
