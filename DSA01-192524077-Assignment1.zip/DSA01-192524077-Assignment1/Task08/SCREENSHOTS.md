# Screenshots for Task08

Place your code snapshot and terminal execution output images here:
- `Task08_code_ss.png`
- `Task08_output_ss.png`
