#include <iostream>
#include <limits>
#include <iomanip>
#include <string>

long long readIntegerSafe(const std::string& prompt, long long minVal, long long maxVal) {
    long long value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            if (value >= minVal && value <= maxVal) {
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                return value;
            }
            std::cout << "Value out of acceptable range [" << minVal << " - " << maxVal << "]. Try again.\n";
        } else {
            std::cout << "Invalid numeric input. Please enter digits only.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }
}

void printFormattedFare(const std::string& passengerName, long long farePaise, long long balancePaise) {
    std::cout << "\n========================================\n"
              << "          NAMMA METRO GATE PASS         \n"
              << "========================================\n"
              << std::left << std::setw(20) << "Passenger:" << passengerName << "\n"
              << std::left << std::setw(20) << "Deducted Fare:" << "Rs " 
              << farePaise / 100 << "." 
              << std::setw(2) << std::setfill('0') << farePaise % 100 << std::setfill(' ') << "\n"
              << std::left << std::setw(20) << "Remaining Balance:" << "Rs " 
              << balancePaise / 100 << "." 
              << std::setw(2) << std::setfill('0') << balancePaise % 100 << std::setfill(' ') << "\n"
              << "========================================\n";
}

int main() {
    long long recharge = 10000; // Simulated input
    printFormattedFare("192524077", 3600, recharge - 3600);
    return 0;
}
