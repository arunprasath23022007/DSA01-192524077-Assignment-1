# Screenshots for Task09

Place your code snapshot and terminal execution output images here:
- `Task09_code_ss.png`
- `Task09_output_ss.png`
