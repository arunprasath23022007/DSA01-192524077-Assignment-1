# Screenshots for Task03

Place your code snapshot and terminal execution output images here:
- `Task03_code_ss.png`
- `Task03_output_ss.png`
