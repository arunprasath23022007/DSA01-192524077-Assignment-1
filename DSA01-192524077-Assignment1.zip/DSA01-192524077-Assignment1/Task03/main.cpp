#include <iostream>
#include <iomanip>

int main() {
    std::cout << "--- Task 03: Data Types and Precision Analysis ---\n";

    // Demonstration of floating-point representation drift vs exact integer paise
    double floatBalance = 100.00;
    floatBalance -= 19.99;
    std::cout << std::fixed << std::setprecision(17);
    std::cout << "Float/Double balance after 100.00 - 19.99: " << floatBalance << "\n";

    long long paiseBalance = 10000; // Rs 100.00
    paiseBalance -= 1999;          // Rs 19.99
    std::cout << "Integer paise balance after 10000 - 1999: " << paiseBalance << " paise\n";
    std::cout << "Exact display: Rs " << paiseBalance / 100 << "." 
              << std::setw(2) << std::setfill('0') << paiseBalance % 100 << "\n";

    return 0;
}
