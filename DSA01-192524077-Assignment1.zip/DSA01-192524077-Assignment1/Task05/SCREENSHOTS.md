# Screenshots for Task05

Place your code snapshot and terminal execution output images here:
- `Task05_code_ss.png`
- `Task05_output_ss.png`
