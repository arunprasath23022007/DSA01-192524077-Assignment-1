# Screenshots for Task12

Place your code snapshot and terminal execution output images here:
- `Task12_code_ss.png`
- `Task12_output_ss.png`
