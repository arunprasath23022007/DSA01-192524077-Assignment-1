# Screenshots for Task01

Place your code snapshot and terminal execution output images here:
- `Task01_code_ss.png`
- `Task01_output_ss.png`
