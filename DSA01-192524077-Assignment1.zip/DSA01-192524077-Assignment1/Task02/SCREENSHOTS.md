# Screenshots for Task02

Place your code snapshot and terminal execution output images here:
- `Task02_code_ss.png`
- `Task02_output_ss.png`
