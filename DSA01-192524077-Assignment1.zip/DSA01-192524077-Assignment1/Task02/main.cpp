#include <iostream>
#include <cstdint>

// Scoped enum prevents namespace pollution and unintended implicit conversions
enum class Zone : uint8_t {
    Inner,
    Middle,
    Outer
};

// constexpr constants evaluated strictly at compile time
constexpr long long MIN_BALANCE_PAISE = 5000LL; // Rs 50
constexpr int PEAK_SURCHARGE_PERCENT = 20;

int main() {
    std::cout << "--- Task 02: Tokens and Scoped Enums ---\n";
    std::cout << "Minimum Balance (paise): " << MIN_BALANCE_PAISE << "\n";
    std::cout << "Peak Surcharge: " << PEAK_SURCHARGE_PERCENT << "%\n";
    std::cout << "Zone enum size in bytes: " << sizeof(Zone::Inner) << " byte(s)\n";
    return 0;
}
