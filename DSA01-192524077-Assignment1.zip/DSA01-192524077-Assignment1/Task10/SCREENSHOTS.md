# Screenshots for Task10

Place your code snapshot and terminal execution output images here:
- `Task10_code_ss.png`
- `Task10_output_ss.png`
